export default class ExcelConstants {
    static readonly TEST_PATH = './src/resources/data/testData.xlsx';
    static readonly SUITE_PATH = '../../resources/data/testData.xlsx';
    static readonly YES = "YES";
}
