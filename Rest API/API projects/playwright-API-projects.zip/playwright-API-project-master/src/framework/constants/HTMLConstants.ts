export default class HTMLConstants {
    static readonly LOADING_IMAGE = "body>.loader";
    static readonly OPTION = "option";
    static readonly SELECTED_OPTION = "option[selected='selected']";
}
