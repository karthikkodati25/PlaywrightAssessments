export default class DatabaseConstants {
    static readonly QUERY_EXECUTION = "Query Execution";
}
