export default class ConfigurationPage {
    static readonly AOS_BACK_END_LINK = "//ul[@class='nav_user_guide_list']/li/a[text()='AOS back end']";
}
