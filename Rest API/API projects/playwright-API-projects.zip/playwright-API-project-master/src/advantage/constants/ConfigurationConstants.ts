export default class ConfigurationConstants {
    static readonly AOS_BACKEND = "AOS Backend";
}
